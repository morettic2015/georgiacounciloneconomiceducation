/**
 *  @Class QuizzUtils
 *  @author Luis Augusto Machado Moretto
 *  @copyright https://morettic.com.br
 * */
var QuizzUtils = function() {

    /**
     * @ Init Quizzz
     * */
    this.initQuizzStats = function() {
        document.getElementById('btContinue').setAttribute('disabled', 'disabled');
    }
    /**
     * Start Quizz
     * */
    this.startQuizz = function() {
        //Init Start Quizz Button
        document.querySelector('#myNavigator').pushPage('quizz.html', {data: {title: 'Start Quizz'}});
    }
    /**
     * @Pause Quizz
     * */
    this.pauseQuizz = function() {
        alert('asd');
        document.querySelector('#myNavigator').pushPage('home.html', {data: {title: 'HOME'}});
        //Enable back button
        document.getElementById('btContinue').removeAttribute('disabled');
    }
}