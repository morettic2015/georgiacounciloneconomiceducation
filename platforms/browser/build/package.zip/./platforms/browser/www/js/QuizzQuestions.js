/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

var questions =
        [
            {
                qID: 1,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 1,
                answers: [
                    {opt: 'The hamburger company relies heavily on natural resources.', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: false},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: true},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 1,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 1,
                answers: [
                    {opt: 'The hamburger company relies heavily on natural resources.', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: false},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: true},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 1,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 1,
                answers: [
                    {opt: 'The hamburger company relies heavily on natural resources.', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: false},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: true},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 1,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 1,
                answers: [
                    {opt: 'The hamburger company relies heavily on natural resources.', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: false},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: true},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 1,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 1,
                answers: [
                    {opt: 'The hamburger company relies heavily on natural resources.', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: false},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: true},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 1,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 1,
                answers: [
                    {opt: 'The hamburger company relies heavily on natural resources.', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: false},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: true},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 1,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 1,
                answers: [
                    {opt: 'The hamburger company relies heavily on natural resources.', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: false},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: true},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 1,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 1,
                answers: [
                    {opt: 'The hamburger company relies heavily on natural resources.', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: false},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: true},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 1,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 1,
                answers: [
                    {opt: 'The hamburger company relies heavily on natural resources.', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: false},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: true},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 1,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 1,
                answers: [
                    {opt: 'The hamburger company relies heavily on natural resources.', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: false},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: true},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 1,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 1,
                answers: [
                    {opt: 'The hamburger company relies heavily on natural resources.', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: false},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: true},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 1,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 1,
                answers: [
                    {opt: 'The hamburger company relies heavily on natural resources.', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: false},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: true},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 1,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 1,
                answers: [
                    {opt: 'The hamburger company relies heavily on natural resources.', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: false},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: true},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 1,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 1,
                answers: [
                    {opt: 'The hamburger company relies heavily on natural resources.', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: false},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: true},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 1,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 1,
                answers: [
                    {opt: 'The hamburger company relies heavily on natural resources.', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: false},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: true},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 1,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 1,
                answers: [
                    {opt: 'The hamburger company relies heavily on natural resources.', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: false},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: true},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 1,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 1,
                answers: [
                    {opt: 'The hamburger company relies heavily on natural resources.', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: false},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: true},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 1,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 1,
                answers: [
                    {opt: 'The hamburger company relies heavily on natural resources.', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: false},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: true},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 1,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 1,
                answers: [
                    {opt: 'The hamburger company relies heavily on natural resources.', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: false},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: true},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 1,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 1,
                answers: [
                    {opt: 'The hamburger company relies heavily on natural resources.', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: false},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: true},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            }, {
                qID: 1,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 1,
                answers: [
                    {opt: 'The hamburger company relies heavily on natural resources.', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: false},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: true},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 1,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 1,
                answers: [
                    {opt: 'The hamburger company relies heavily on natural resources.', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: false},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: true},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 1,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 1,
                answers: [
                    {opt: 'The hamburger company relies heavily on natural resources.', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: false},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: true},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 1,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 1,
                answers: [
                    {opt: 'The hamburger company relies heavily on natural resources.', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: false},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: true},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 1,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 1,
                answers: [
                    {opt: 'The hamburger company relies heavily on natural resources.', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: false},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: true},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 1,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 1,
                answers: [
                    {opt: 'The hamburger company relies heavily on natural resources.', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: false},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: true},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 1,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 1,
                answers: [
                    {opt: 'The hamburger company relies heavily on natural resources.', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: false},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: true},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 1,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 1,
                answers: [
                    {opt: 'The hamburger company relies heavily on natural resources.', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: false},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: true},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 1,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 1,
                answers: [
                    {opt: 'The hamburger company relies heavily on natural resources.', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: false},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: true},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 1,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 1,
                answers: [
                    {opt: 'The hamburger company relies heavily on natural resources.', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: false},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: true},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            }, {
                qID: 1,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 1,
                answers: [
                    {opt: 'The hamburger company relies heavily on natural resources.', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: false},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: true},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 1,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 1,
                answers: [
                    {opt: 'The hamburger company relies heavily on natural resources.', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: false},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: true},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 1,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 1,
                answers: [
                    {opt: 'The hamburger company relies heavily on natural resources.', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: false},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: true},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 1,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 1,
                answers: [
                    {opt: 'The hamburger company relies heavily on natural resources.', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: false},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: true},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 1,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 1,
                answers: [
                    {opt: 'The hamburger company relies heavily on natural resources.', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: false},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: true},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 1,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 1,
                answers: [
                    {opt: 'The hamburger company relies heavily on natural resources.', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: false},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: true},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 1,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 1,
                answers: [
                    {opt: 'The hamburger company relies heavily on natural resources.', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: false},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: true},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 1,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 1,
                answers: [
                    {opt: 'The hamburger company relies heavily on natural resources.', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: false},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: true},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 1,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 1,
                answers: [
                    {opt: 'The hamburger company relies heavily on natural resources.', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: false},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: true},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 1,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 1,
                answers: [
                    {opt: 'The hamburger company relies heavily on natural resources.', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: false},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: true},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            }, {
                qID: 1,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 1,
                answers: [
                    {opt: 'The hamburger company relies heavily on natural resources.', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: false},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: true},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 1,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 1,
                answers: [
                    {opt: 'The hamburger company relies heavily on natural resources.', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: false},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: true},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 1,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 1,
                answers: [
                    {opt: 'The hamburger company relies heavily on natural resources.', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: false},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: true},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 1,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 1,
                answers: [
                    {opt: 'The hamburger company relies heavily on natural resources.', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: false},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: true},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 1,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 1,
                answers: [
                    {opt: 'The hamburger company relies heavily on natural resources.', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: false},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: true},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 1,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 1,
                answers: [
                    {opt: 'The hamburger company relies heavily on natural resources.', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: false},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: true},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 1,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 1,
                answers: [
                    {opt: 'The hamburger company relies heavily on natural resources.', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: false},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: true},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 1,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 1,
                answers: [
                    {opt: 'The hamburger company relies heavily on natural resources.', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: false},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: true},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 1,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 1,
                answers: [
                    {opt: 'The hamburger company relies heavily on natural resources.', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: false},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: true},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 51,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 2,
                answers: [
                    {opt: 'the dough used to bake the cookies', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: true},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: false},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 51,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 2,
                answers: [
                    {opt: 'the dough used to bake the cookies', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: true},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: false},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 51,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 2,
                answers: [
                    {opt: 'the dough used to bake the cookies', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: true},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: false},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 51,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 2,
                answers: [
                    {opt: 'the dough used to bake the cookies', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: true},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: false},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 51,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 2,
                answers: [
                    {opt: 'the dough used to bake the cookies', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: true},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: false},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 51,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 2,
                answers: [
                    {opt: 'the dough used to bake the cookies', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: true},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: false},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 51,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 2,
                answers: [
                    {opt: 'the dough used to bake the cookies', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: true},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: false},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 51,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 2,
                answers: [
                    {opt: 'the dough used to bake the cookies', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: true},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: false},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 51,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 2,
                answers: [
                    {opt: 'the dough used to bake the cookies', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: true},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: false},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 51,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 2,
                answers: [
                    {opt: 'the dough used to bake the cookies', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: true},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: false},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            }, {
                qID: 51,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 2,
                answers: [
                    {opt: 'the dough used to bake the cookies', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: true},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: false},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 51,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 2,
                answers: [
                    {opt: 'the dough used to bake the cookies', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: true},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: false},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 51,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 2,
                answers: [
                    {opt: 'the dough used to bake the cookies', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: true},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: false},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 51,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 2,
                answers: [
                    {opt: 'the dough used to bake the cookies', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: true},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: false},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 51,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 2,
                answers: [
                    {opt: 'the dough used to bake the cookies', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: true},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: false},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 51,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 2,
                answers: [
                    {opt: 'the dough used to bake the cookies', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: true},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: false},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 51,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 2,
                answers: [
                    {opt: 'the dough used to bake the cookies', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: true},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: false},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 51,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 2,
                answers: [
                    {opt: 'the dough used to bake the cookies', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: true},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: false},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 51,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 2,
                answers: [
                    {opt: 'the dough used to bake the cookies', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: true},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: false},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 51,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 2,
                answers: [
                    {opt: 'the dough used to bake the cookies', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: true},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: false},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            }, {
                qID: 51,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 2,
                answers: [
                    {opt: 'the dough used to bake the cookies', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: true},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: false},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 51,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 2,
                answers: [
                    {opt: 'the dough used to bake the cookies', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: true},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: false},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 51,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 2,
                answers: [
                    {opt: 'the dough used to bake the cookies', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: true},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: false},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 51,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 2,
                answers: [
                    {opt: 'the dough used to bake the cookies', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: true},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: false},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 51,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 2,
                answers: [
                    {opt: 'the dough used to bake the cookies', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: true},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: false},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 51,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 2,
                answers: [
                    {opt: 'the dough used to bake the cookies', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: true},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: false},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 51,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 2,
                answers: [
                    {opt: 'the dough used to bake the cookies', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: true},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: false},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 51,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 2,
                answers: [
                    {opt: 'the dough used to bake the cookies', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: true},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: false},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 51,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 2,
                answers: [
                    {opt: 'the dough used to bake the cookies', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: true},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: false},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 51,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 2,
                answers: [
                    {opt: 'the dough used to bake the cookies', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: true},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: false},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            }, {
                qID: 51,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 2,
                answers: [
                    {opt: 'the dough used to bake the cookies', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: true},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: false},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 51,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 2,
                answers: [
                    {opt: 'the dough used to bake the cookies', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: true},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: false},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 51,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 2,
                answers: [
                    {opt: 'the dough used to bake the cookies', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: true},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: false},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 51,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 2,
                answers: [
                    {opt: 'the dough used to bake the cookies', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: true},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: false},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 51,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 2,
                answers: [
                    {opt: 'the dough used to bake the cookies', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: true},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: false},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 51,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 2,
                answers: [
                    {opt: 'the dough used to bake the cookies', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: true},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: false},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 51,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 2,
                answers: [
                    {opt: 'the dough used to bake the cookies', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: true},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: false},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 51,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 2,
                answers: [
                    {opt: 'the dough used to bake the cookies', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: true},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: false},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 51,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 2,
                answers: [
                    {opt: 'the dough used to bake the cookies', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: true},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: false},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 51,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 2,
                answers: [
                    {opt: 'the dough used to bake the cookies', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: true},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: false},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            }, {
                qID: 51,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 2,
                answers: [
                    {opt: 'the dough used to bake the cookies', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: true},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: false},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 51,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 2,
                answers: [
                    {opt: 'the dough used to bake the cookies', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: true},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: false},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 51,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 2,
                answers: [
                    {opt: 'the dough used to bake the cookies', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: true},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: false},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 51,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 2,
                answers: [
                    {opt: 'the dough used to bake the cookies', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: true},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: false},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 51,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 2,
                answers: [
                    {opt: 'the dough used to bake the cookies', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: true},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: false},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 51,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 2,
                answers: [
                    {opt: 'the dough used to bake the cookies', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: true},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: false},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 51,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 2,
                answers: [
                    {opt: 'the dough used to bake the cookies', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: true},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: false},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 51,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 2,
                answers: [
                    {opt: 'the dough used to bake the cookies', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: true},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: false},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 51,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 2,
                answers: [
                    {opt: 'the dough used to bake the cookies', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: true},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: false},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 51,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 2,
                answers: [
                    {opt: 'the dough used to bake the cookies', isFine: false},
                    {opt: 'Shay is not an entrepreneur because she only uses one resource.', isFine: true},
                    {opt: 'Owning a hamburger company is very capital-intensive.', isFine: false},
                    {opt: 'Scarcity does not affect Shay because she has all the ingredients she needs.', isFine: false}
                ]
            },
            {
                qID: 151,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 3,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 151,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 3,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 151,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 3,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 151,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 3,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 151,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 3,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 151,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 3,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 151,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 3,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 151,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 3,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 151,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 3,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 151,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 3,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 151,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 3,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            }, {
                qID: 151,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 3,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 151,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 3,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 151,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 3,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 151,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 3,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 151,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 3,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 151,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 3,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 151,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 3,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 151,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 3,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 151,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 3,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 151,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 3,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 151,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 3,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            }, {
                qID: 151,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 3,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 151,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 3,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 151,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 3,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 151,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 3,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 151,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 3,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 151,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 3,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 151,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 3,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 151,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 3,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 151,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 3,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 151,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 3,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 151,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 3,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            }, {
                qID: 151,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 3,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 151,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 3,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 151,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 3,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 151,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 3,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 151,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 3,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 151,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 3,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 151,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 3,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 151,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 3,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 151,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 3,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 151,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 3,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 151,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 3,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            }, {
                qID: 151,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 3,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 151,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 3,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 151,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 3,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 151,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 3,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 151,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 3,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 151,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 3,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 151,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 3,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 151,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 3,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 151,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 3,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 151,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 3,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 151,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 3,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 251,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 4,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 251,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 4,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 251,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 4,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 251,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 4,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 251,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 4,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 251,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 4,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 251,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 4,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 251,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 4,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 251,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 4,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 251,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 4,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 251,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 4,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 251,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 4,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 251,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 4,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 251,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 4,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 251,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 4,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 251,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 4,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 251,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 4,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 251,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 4,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 251,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 4,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 251,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 4,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 251,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 4,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 251,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 4,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 251,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 4,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 251,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 4,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 251,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 4,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 251,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 4,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 251,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 4,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 251,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 4,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 251,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 4,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 251,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 4,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 251,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 4,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 251,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 4,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 251,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 4,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 251,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 4,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 251,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 4,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 251,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 4,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 251,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 4,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 251,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 4,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            }, {
                qID: 251,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 4,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            }, {
                qID: 251,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 4,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 251,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 4,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            }, {
                qID: 251,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 4,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            }, {
                qID: 251,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 4,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 251,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 4,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 251,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 4,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 251,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 4,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 251,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 4,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 251,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 4,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 251,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 4,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 251,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 4,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            }, {
                qID: 251,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 4,
                answers: [
                    {opt: 'Light fixtures to help display the artwork', isFine: false},
                    {opt: 'A security system to protect the artwork', isFine: true},
                    {opt: 'Knowledge of trends in modern art', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            }, {
                qID: 351,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 5,
                answers: [
                    {opt: 'Over the surface remains the fingerprint', isFine: true},
                    {opt: 'A security system to protect the artwork', isFine: false},
                    {opt: 'Knowledge Sharing is power', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 351,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 5,
                answers: [
                    {opt: 'Over the surface remains the fingerprint', isFine: true},
                    {opt: 'A security system to protect the artwork', isFine: false},
                    {opt: 'Knowledge Sharing is power', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 351,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 5,
                answers: [
                    {opt: 'Over the surface remains the fingerprint', isFine: true},
                    {opt: 'A security system to protect the artwork', isFine: false},
                    {opt: 'Knowledge Sharing is power', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 351,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 5,
                answers: [
                    {opt: 'Over the surface remains the fingerprint', isFine: true},
                    {opt: 'A security system to protect the artwork', isFine: false},
                    {opt: 'Knowledge Sharing is power', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 351,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 5,
                answers: [
                    {opt: 'Over the surface remains the fingerprint', isFine: true},
                    {opt: 'A security system to protect the artwork', isFine: false},
                    {opt: 'Knowledge Sharing is power', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 351,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 5,
                answers: [
                    {opt: 'Over the surface remains the fingerprint', isFine: true},
                    {opt: 'A security system to protect the artwork', isFine: false},
                    {opt: 'Knowledge Sharing is power', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 351,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 5,
                answers: [
                    {opt: 'Over the surface remains the fingerprint', isFine: true},
                    {opt: 'A security system to protect the artwork', isFine: false},
                    {opt: 'Knowledge Sharing is power', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 351,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 5,
                answers: [
                    {opt: 'Over the surface remains the fingerprint', isFine: true},
                    {opt: 'A security system to protect the artwork', isFine: false},
                    {opt: 'Knowledge Sharing is power', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 351,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 5,
                answers: [
                    {opt: 'Over the surface remains the fingerprint', isFine: true},
                    {opt: 'A security system to protect the artwork', isFine: false},
                    {opt: 'Knowledge Sharing is power', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 351,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 5,
                answers: [
                    {opt: 'Over the surface remains the fingerprint', isFine: true},
                    {opt: 'A security system to protect the artwork', isFine: false},
                    {opt: 'Knowledge Sharing is power', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 351,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 5,
                answers: [
                    {opt: 'Over the surface remains the fingerprint', isFine: true},
                    {opt: 'A security system to protect the artwork', isFine: false},
                    {opt: 'Knowledge Sharing is power', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 351,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 5,
                answers: [
                    {opt: 'Over the surface remains the fingerprint', isFine: true},
                    {opt: 'A security system to protect the artwork', isFine: false},
                    {opt: 'Knowledge Sharing is power', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 351,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 5,
                answers: [
                    {opt: 'Over the surface remains the fingerprint', isFine: true},
                    {opt: 'A security system to protect the artwork', isFine: false},
                    {opt: 'Knowledge Sharing is power', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 351,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 5,
                answers: [
                    {opt: 'Over the surface remains the fingerprint', isFine: true},
                    {opt: 'A security system to protect the artwork', isFine: false},
                    {opt: 'Knowledge Sharing is power', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 351,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 5,
                answers: [
                    {opt: 'Over the surface remains the fingerprint', isFine: true},
                    {opt: 'A security system to protect the artwork', isFine: false},
                    {opt: 'Knowledge Sharing is power', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 351,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 5,
                answers: [
                    {opt: 'Over the surface remains the fingerprint', isFine: true},
                    {opt: 'A security system to protect the artwork', isFine: false},
                    {opt: 'Knowledge Sharing is power', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 351,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 5,
                answers: [
                    {opt: 'Over the surface remains the fingerprint', isFine: true},
                    {opt: 'A security system to protect the artwork', isFine: false},
                    {opt: 'Knowledge Sharing is power', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 351,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 5,
                answers: [
                    {opt: 'Over the surface remains the fingerprint', isFine: true},
                    {opt: 'A security system to protect the artwork', isFine: false},
                    {opt: 'Knowledge Sharing is power', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 351,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 5,
                answers: [
                    {opt: 'Over the surface remains the fingerprint', isFine: true},
                    {opt: 'A security system to protect the artwork', isFine: false},
                    {opt: 'Knowledge Sharing is power', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 351,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 5,
                answers: [
                    {opt: 'Over the surface remains the fingerprint', isFine: true},
                    {opt: 'A security system to protect the artwork', isFine: false},
                    {opt: 'Knowledge Sharing is power', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 351,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 5,
                answers: [
                    {opt: 'Over the surface remains the fingerprint', isFine: true},
                    {opt: 'A security system to protect the artwork', isFine: false},
                    {opt: 'Knowledge Sharing is power', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 351,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 5,
                answers: [
                    {opt: 'Over the surface remains the fingerprint', isFine: true},
                    {opt: 'A security system to protect the artwork', isFine: false},
                    {opt: 'Knowledge Sharing is power', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 351,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 5,
                answers: [
                    {opt: 'Over the surface remains the fingerprint', isFine: true},
                    {opt: 'A security system to protect the artwork', isFine: false},
                    {opt: 'Knowledge Sharing is power', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 351,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 5,
                answers: [
                    {opt: 'Over the surface remains the fingerprint', isFine: true},
                    {opt: 'A security system to protect the artwork', isFine: false},
                    {opt: 'Knowledge Sharing is power', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 351,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 5,
                answers: [
                    {opt: 'Over the surface remains the fingerprint', isFine: true},
                    {opt: 'A security system to protect the artwork', isFine: false},
                    {opt: 'Knowledge Sharing is power', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 351,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 5,
                answers: [
                    {opt: 'Over the surface remains the fingerprint', isFine: true},
                    {opt: 'A security system to protect the artwork', isFine: false},
                    {opt: 'Knowledge Sharing is power', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 351,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 5,
                answers: [
                    {opt: 'Over the surface remains the fingerprint', isFine: true},
                    {opt: 'A security system to protect the artwork', isFine: false},
                    {opt: 'Knowledge Sharing is power', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 351,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 5,
                answers: [
                    {opt: 'Over the surface remains the fingerprint', isFine: true},
                    {opt: 'A security system to protect the artwork', isFine: false},
                    {opt: 'Knowledge Sharing is power', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 351,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 5,
                answers: [
                    {opt: 'Over the surface remains the fingerprint', isFine: true},
                    {opt: 'A security system to protect the artwork', isFine: false},
                    {opt: 'Knowledge Sharing is power', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 351,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 5,
                answers: [
                    {opt: 'Over the surface remains the fingerprint', isFine: true},
                    {opt: 'A security system to protect the artwork', isFine: false},
                    {opt: 'Knowledge Sharing is power', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            }, {
                qID: 351,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 5,
                answers: [
                    {opt: 'Over the surface remains the fingerprint', isFine: true},
                    {opt: 'A security system to protect the artwork', isFine: false},
                    {opt: 'Knowledge Sharing is power', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 351,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 5,
                answers: [
                    {opt: 'Over the surface remains the fingerprint', isFine: true},
                    {opt: 'A security system to protect the artwork', isFine: false},
                    {opt: 'Knowledge Sharing is power', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 351,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 5,
                answers: [
                    {opt: 'Over the surface remains the fingerprint', isFine: true},
                    {opt: 'A security system to protect the artwork', isFine: false},
                    {opt: 'Knowledge Sharing is power', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 351,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 5,
                answers: [
                    {opt: 'Over the surface remains the fingerprint', isFine: true},
                    {opt: 'A security system to protect the artwork', isFine: false},
                    {opt: 'Knowledge Sharing is power', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 351,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 5,
                answers: [
                    {opt: 'Over the surface remains the fingerprint', isFine: true},
                    {opt: 'A security system to protect the artwork', isFine: false},
                    {opt: 'Knowledge Sharing is power', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 351,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 5,
                answers: [
                    {opt: 'Over the surface remains the fingerprint', isFine: true},
                    {opt: 'A security system to protect the artwork', isFine: false},
                    {opt: 'Knowledge Sharing is power', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 351,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 5,
                answers: [
                    {opt: 'Over the surface remains the fingerprint', isFine: true},
                    {opt: 'A security system to protect the artwork', isFine: false},
                    {opt: 'Knowledge Sharing is power', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 351,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 5,
                answers: [
                    {opt: 'Over the surface remains the fingerprint', isFine: true},
                    {opt: 'A security system to protect the artwork', isFine: false},
                    {opt: 'Knowledge Sharing is power', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 351,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 5,
                answers: [
                    {opt: 'Over the surface remains the fingerprint', isFine: true},
                    {opt: 'A security system to protect the artwork', isFine: false},
                    {opt: 'Knowledge Sharing is power', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 351,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 5,
                answers: [
                    {opt: 'Over the surface remains the fingerprint', isFine: true},
                    {opt: 'A security system to protect the artwork', isFine: false},
                    {opt: 'Knowledge Sharing is power', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 351,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 5,
                answers: [
                    {opt: 'Over the surface remains the fingerprint', isFine: true},
                    {opt: 'A security system to protect the artwork', isFine: false},
                    {opt: 'Knowledge Sharing is power', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 351,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 5,
                answers: [
                    {opt: 'Over the surface remains the fingerprint', isFine: true},
                    {opt: 'A security system to protect the artwork', isFine: false},
                    {opt: 'Knowledge Sharing is power', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 351,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 5,
                answers: [
                    {opt: 'Over the surface remains the fingerprint', isFine: true},
                    {opt: 'A security system to protect the artwork', isFine: false},
                    {opt: 'Knowledge Sharing is power', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 351,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 5,
                answers: [
                    {opt: 'Over the surface remains the fingerprint', isFine: true},
                    {opt: 'A security system to protect the artwork', isFine: false},
                    {opt: 'Knowledge Sharing is power', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 351,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 5,
                answers: [
                    {opt: 'Over the surface remains the fingerprint', isFine: true},
                    {opt: 'A security system to protect the artwork', isFine: false},
                    {opt: 'Knowledge Sharing is power', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 351,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 5,
                answers: [
                    {opt: 'Over the surface remains the fingerprint', isFine: true},
                    {opt: 'A security system to protect the artwork', isFine: false},
                    {opt: 'Knowledge Sharing is power', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            }, {
                qID: 351,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 5,
                answers: [
                    {opt: 'Over the surface remains the fingerprint', isFine: true},
                    {opt: 'A security system to protect the artwork', isFine: false},
                    {opt: 'Knowledge Sharing is power', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 351,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 5,
                answers: [
                    {opt: 'Over the surface remains the fingerprint', isFine: true},
                    {opt: 'A security system to protect the artwork', isFine: false},
                    {opt: 'Knowledge Sharing is power', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 351,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 5,
                answers: [
                    {opt: 'Over the surface remains the fingerprint', isFine: true},
                    {opt: 'A security system to protect the artwork', isFine: false},
                    {opt: 'Knowledge Sharing is power', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 351,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 5,
                answers: [
                    {opt: 'Over the surface remains the fingerprint', isFine: true},
                    {opt: 'A security system to protect the artwork', isFine: false},
                    {opt: 'Knowledge Sharing is power', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 351,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 5,
                answers: [
                    {opt: 'Over the surface remains the fingerprint', isFine: true},
                    {opt: 'A security system to protect the artwork', isFine: false},
                    {opt: 'Knowledge Sharing is power', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
            {
                qID: 351,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 5,
                answers: [
                    {opt: 'Over the surface remains the fingerprint', isFine: true},
                    {opt: 'A security system to protect the artwork', isFine: false},
                    {opt: 'Knowledge Sharing is power', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            }, {
                qID: 351,
                excerpt: 'Based SOLELY on this information, which statement is correct?',
                title: 'Shay owns and operates a hamburger company where she uses the following items on a regular basis:<ul><li>potatoes</li><li>wheat buns</li><li>meat</li><li>lettuce</li><li>onions</li></ul>',
                img: null,
                explanation: "This is where the explanation of the question's correct answer would go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nunc libero, finibus vitae laoreet vitae, posuere vel sem. Praesent pulvinar quis tellus vitae rutrum. Cras mollis ultricies pharetra.",
                group: 5,
                answers: [
                    {opt: 'Over the surface remains the fingerprint', isFine: true},
                    {opt: 'A security system to protect the artwork', isFine: false},
                    {opt: 'Knowledge Sharing is power', isFine: false},
                    {opt: 'A series of paintings by a prominent local artist', isFine: false}
                ]
            },
        ]

