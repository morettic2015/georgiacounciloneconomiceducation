/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

var questions =
        [
            {
                questionId: 1,
                excerpt: 'Do you know me??? So....',
                title: 'Whats My Name?',
                img: '/img/teste.png',
                group: 1,
                answers: [
                    {option: 'Clinton', isFine: false},
                    {option: 'Bush', isFine: false},
                    {option: 'Budda', isFine: true},
                    {option: 'Obama', isFine: false}
                ]
            },
            {
                questionId: 2,
                excerpt: 'Do you know me??? So....',
                title: 'Whats My Name?',
                img: '/img/teste.png',
                group: 2,
                answers: [
                    {option: 'Clinton', isFine: false},
                    {option: 'Bush', isFine: false},
                    {option: 'Budda', isFine: true},
                    {option: 'Obama', isFine: false}
                ]
            }
        ]

