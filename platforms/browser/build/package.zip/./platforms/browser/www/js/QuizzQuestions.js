/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

var questions =
        [
            {
                qID: 1,
                excerpt: 'Do you know me??? So....',
                title: 'Whats My Name?',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                group: 2,
                answers: [
                    {opt: 'Clinton', isFine: false},
                    {opt: 'Bushssssssssssssss', isFine: false},
                    {opt: 'Budda', isFine: true},
                    {opt: 'Obama', isFine: false}
                ]
            },
            {
                qID: 2,
                excerpt: 'Do you know me??? So...2.',
                title: 'Whats My Name?',
                img: null,
                group: 4,
                answers: [
                    {opt: 'Clinton 2', isFine: false},
                    {opt: 'Bush ssssssssssssssss2', isFine: false},
                    {opt: 'Budda 2', isFine: true},
                    {opt: 'Obama 2', isFine: false}
                ]
            },
            {
                qID: 3,
                excerpt: 'Do you know me??? So...2.',
                title: 'Whats My Name?',
                img: null,
                group: 3,
                answers: [
                    {opt: 'Clinton 23', isFine: false},
                    {opt: 'Bush 23', isFine: false},
                    {opt: 'Budda 23', isFine: true},
                    {opt: 'Obama 2dddddddddddd3', isFine: false}
                ]
            },
            {
                qID: 4,
                excerpt: 'Do you know me??? So...2.',
                title: 'Whats My Name?',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                group: 1,
                answers: [
                    {opt: 'Clinton 2', isFine: false},
                    {opt: 'Bush 2', isFine: false},
                    {opt: 'Budda 2aaaaaaaaaaaaaaaa', isFine: true},
                    {opt: 'Obama 2', isFine: false}
                ]
            },
            {
                qID: 5,
                excerpt: 'Do you know me??? So...2.',
                title: 'Whats My Name?',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                group: 1,
                answers: [
                    {opt: 'Clinton 2', isFine: false},
                    {opt: 'Bush 2', isFine: false},
                    {opt: 'Budda 2', isFine: true},
                    {opt: 'Obama 2', isFine: false}
                ]
            },
            {
                qID: 6,
                excerpt: 'Do you know me??? So...2.',
                title: 'Whats My Name?',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                group: 1,
                answers: [
                    {opt: 'Clinton 23', isFine: false},
                    {opt: 'Bush 23', isFine: false},
                    {opt: 'Budda 23', isFine: true},
                    {opt: 'Obama 23', isFine: false}
                ]
            },
            {
                qID: 7,
                excerpt: 'Do you know me??? So...2.',
                title: 'Whats My Name?',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                group: 1,
                answers: [
                    {opt: 'Clinton 2', isFine: false},
                    {opt: 'Bush 2', isFine: false},
                    {opt: 'Budda sssssssssssssss2', isFine: true},
                    {opt: 'Obama 2', isFine: false}
                ]
            },
            {
                qID: 8,
                excerpt: 'Do you know me??? So...2.',
                title: 'Whats My Name?',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                group: 1,
                answers: [
                    {opt: 'Clinton 2', isFine: false},
                    {opt: 'Bush 2', isFine: false},
                    {opt: 'Budda 2', isFine: true},
                    {opt: 'Obama 2', isFine: false}
                ]
            },
            {
                qID: 9,
                excerpt: 'Do you know me??? So...2.',
                title: 'Whats My Name?',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                group: 1,
                answers: [
                    {opt: 'Clinton 23', isFine: false},
                    {opt: 'Bush 23', isFine: false},
                    {opt: 'Budda 23', isFine: true},
                    {opt: 'Obama 23', isFine: false}
                ]
            },
            {
                qID: 10,
                excerpt: 'Do you know me??? So...2.',
                title: 'Whats My Name?',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                group: 1,
                answers: [
                    {opt: 'Clinton 2', isFine: false},
                    {opt: 'Bush 2tttttttttttttt', isFine: false},
                    {opt: 'Budda 2', isFine: true},
                    {opt: 'Obama 2', isFine: false}
                ]
            },
            {
                qID: 11,
                excerpt: 'Do you know me??? So....',
                title: 'Whats My Name?',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                group: 5,
                answers: [
                    {opt: 'Clinton', isFine: false},
                    {opt: 'Bushttttttttttttttt', isFine: false},
                    {opt: 'Budda', isFine: true},
                    {opt: 'Obama', isFine: false}
                ]
            },
            {
                qID: 12,
                excerpt: 'Do you know me??? So...2.',
                title: 'Whats My Name?',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                group: 5,
                answers: [
                    {opt: 'Clinton 2', isFine: false},
                    {opt: 'Bush 2', isFine: false},
                    {opt: 'Budda 2', isFine: true},
                    {opt: 'Obama 2', isFine: false}
                ]
            },
            {
                qID: 13,
                excerpt: 'Do you know me??? So...2.',
                title: 'Whats My Name?',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                group: 5,
                answers: [
                    {opt: 'Clinton 23', isFine: false},
                    {opt: 'Bush 23', isFine: false},
                    {opt: 'Budda 23', isFine: true},
                    {opt: 'Obama 23', isFine: false}
                ]
            },
            {
                qID: 14,
                excerpt: 'Do you know me??? So...2.',
                title: 'Whats My Name?',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                group: 5,
                answers: [
                    {opt: 'Clinton 2', isFine: false},
                    {opt: 'Bush 2', isFine: false},
                    {opt: 'Budda 2', isFine: true},
                    {opt: 'Obama 2', isFine: false}
                ]
            },
            {
                qID: 15,
                excerpt: 'Do you know me??? So...2.',
                title: 'Whats My Name?',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                group: 5,
                answers: [
                    {opt: 'Clinton 2', isFine: false},
                    {opt: 'Bush 2', isFine: false},
                    {opt: 'Budda 2', isFine: true},
                    {opt: 'Obama 2', isFine: false}
                ]
            },
            {
                qID: 16,
                excerpt: 'Do you know me??? So...2.',
                title: 'Whats My Name?',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                group: 4,
                answers: [
                    {opt: 'Clinton 23', isFine: false},
                    {opt: 'Bush 23', isFine: false},
                    {opt: 'Budda 23', isFine: true},
                    {opt: 'Obama 23', isFine: false}
                ]
            },
            {
                qID: 17,
                excerpt: 'Do you know me??? So...2.',
                title: 'Whats My Name?',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                group: 4,
                answers: [
                    {opt: 'Clinton 2', isFine: false},
                    {opt: 'Bush 2', isFine: false},
                    {opt: 'Budda 2', isFine: true},
                    {opt: 'Obama 2', isFine: false}
                ]
            },
            {
                qID: 18,
                excerpt: 'Do you know me??? So...2.',
                title: 'Whats My Name?',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                group: 4,
                answers: [
                    {opt: 'Clinton 2', isFine: false},
                    {opt: 'Bush 2', isFine: false},
                    {opt: 'Budda 2', isFine: true},
                    {opt: 'Obama 2', isFine: false}
                ]
            },
            {
                qID: 19,
                excerpt: 'Do you know me??? So...2.',
                title: 'Whats My Name?',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                group: 4,
                answers: [
                    {opt: 'Clinton 23', isFine: false},
                    {opt: 'Bush 23', isFine: false},
                    {opt: 'Budda 23', isFine: true},
                    {opt: 'Obama 23', isFine: false}
                ]
            },
            {
                qID: 20,
                excerpt: 'Do you know me??? So...2.',
                title: 'Whats My Name?',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                group: 3,
                answers: [
                    {opt: 'Clinton 2', isFine: false},
                    {opt: 'Bush 2', isFine: false},
                    {opt: 'Budda 2', isFine: true},
                    {opt: 'Obama 2', isFine: false}
                ]
            },
            {
                qID: 21,
                excerpt: 'Do you know me??? So....',
                title: 'Whats My Name?',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                group: 3,
                answers: [
                    {opt: 'Clinton', isFine: false},
                    {opt: 'Bush', isFine: false},
                    {opt: 'Budda', isFine: true},
                    {opt: 'Obama', isFine: false}
                ]
            },
            {
                qID: 22,
                excerpt: 'Do you know me??? So...2.',
                title: 'Whats My Name?',
                img: null,
                group: 3,
                answers: [
                    {opt: 'Clinton 2', isFine: false},
                    {opt: 'Bush 2', isFine: false},
                    {opt: 'Budda 2', isFine: true},
                    {opt: 'Obama 2', isFine: false}
                ]
            },
            {
                qID: 23,
                excerpt: 'Do you know me??? So...2.',
                title: 'Whats My Name?',
                img: null,
                group: 3,
                answers: [
                    {opt: 'Clinton 23', isFine: false},
                    {opt: 'Bush 23', isFine: false},
                    {opt: 'Budda 23', isFine: true},
                    {opt: 'Obama 23', isFine: false}
                ]
            },
            {
                qID: 24,
                excerpt: 'Do you know me??? So...2.',
                title: 'Whats My Name?',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                group: 3,
                answers: [
                    {opt: 'Clinton 2', isFine: false},
                    {opt: 'Bush 2', isFine: false},
                    {opt: 'Budda 2', isFine: true},
                    {opt: 'Obama 2', isFine: false}
                ]
            },
            {
                qID: 25,
                excerpt: 'Do you know me??? So...2.',
                title: 'Whats My Name?',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                group: 3,
                answers: [
                    {opt: 'Clinton 2', isFine: false},
                    {opt: 'Bush 2', isFine: false},
                    {opt: 'Budda 2', isFine: true},
                    {opt: 'Obama 2', isFine: false}
                ]
            },
            {
                qID: 26,
                excerpt: 'Do you know me??? So...2.',
                title: 'Whats My Name?',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                group: 1,
                answers: [
                    {opt: 'Clinton 23', isFine: false},
                    {opt: 'Bush 23', isFine: false},
                    {opt: 'Budda 23', isFine: true},
                    {opt: 'Obama 23', isFine: false}
                ]
            },
            {
                qID: 27,
                excerpt: 'Do you know me??? So...2.',
                title: 'Whats My Name?',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                group: 1,
                answers: [
                    {opt: 'Clinton 2', isFine: false},
                    {opt: 'Bush 2', isFine: false},
                    {opt: 'Budda 2', isFine: true},
                    {opt: 'Obama 2', isFine: false}
                ]
            },
            {
                qID: 28,
                excerpt: 'Do you know me??? So...2.',
                title: 'Whats My Name?',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                group: 1,
                answers: [
                    {opt: 'Clinton 2', isFine: false},
                    {opt: 'Bush 2', isFine: false},
                    {opt: 'Budda 2', isFine: true},
                    {opt: 'Obama 2', isFine: false}
                ]
            },
            {
                qID: 29,
                excerpt: 'Do you know me??? So...2.',
                title: 'Whats My Name?',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                group: 1,
                answers: [
                    {opt: 'Clinton 23', isFine: false},
                    {opt: 'Bush 23', isFine: false},
                    {opt: 'Budda 23', isFine: true},
                    {opt: 'Obama 23', isFine: false}
                ]
            },
            {
                qID: 30,
                excerpt: 'Do you know me??? So...2+2+2-2-2-2.',
                title: 'Whats My Name?',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                group: 2,
                answers: [
                    {opt: 'Clinton 2', isFine: false},
                    {opt: 'Bush 2', isFine: false},
                    {opt: '0', isFine: true},
                    {opt: 'Obama 2', isFine: false}
                ]
            },
            {
                qID: 31,
                excerpt: 'Do you know me??? So.... 5+5',
                title: 'From Math',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                group: 2,
                answers: [
                    {opt: 'Clinton', isFine: false},
                    {opt: 'Bush', isFine: false},
                    {opt: '10', isFine: true},
                    {opt: 'Obama', isFine: false}
                ]
            },
            {
                qID: 32,
                excerpt: 'Do you know me??? So...(2/0)+1.',
                title: 'From Math',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                group: 2,
                answers: [
                    {opt: 'Clinton 2', isFine: false},
                    {opt: 'Bush 2', isFine: false},
                    {opt: '1', isFine: true},
                    {opt: 'Obama 2', isFine: false}
                ]
            },
            {
                qID: 33,
                excerpt: '1982+35',
                title: 'From Math',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                group: 2,
                answers: [
                    {opt: 'Clinton 23', isFine: false},
                    {opt: 'Bush 23', isFine: false},
                    {opt: '2017', isFine: true},
                    {opt: 'Obama 23', isFine: false}
                ]
            },
            {
                qID: 34,
                excerpt: '2017-1979',
                title: 'From Math',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                group: 2,
                answers: [
                    {opt: 'Clinton 2', isFine: false},
                    {opt: 'Bush 2', isFine: false},
                    {opt: '38', isFine: true},
                    {opt: 'Obama 2', isFine: false}
                ]
            },
            {
                qID: 35,
                excerpt: 'How Much??? So...2+211',
                title: 'From Math',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                group: 3,
                answers: [
                    {opt: 'Clinton 2', isFine: false},
                    {opt: 'Bush 2', isFine: false},
                    {opt: '2013', isFine: true},
                    {opt: 'Obama 2', isFine: false}
                ]
            },
            {
                qID: 36,
                excerpt: '1997 + 20',
                title: 'From Math',
                img: null,
                group: 3,
                answers: [
                    {opt: 'Clinton 23', isFine: false},
                    {opt: 'Bush 23', isFine: false},
                    {opt: '2017', isFine: true},
                    {opt: 'Obama 23', isFine: false}
                ]
            },
            {
                qID: 37,
                excerpt: 'How Much??? So...2+21',
                title: 'From Math',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                group: 3,
                answers: [
                    {opt: 'Clinton 2', isFine: false},
                    {opt: 'Bush 2', isFine: false},
                    {opt: '23', isFine: true},
                    {opt: 'Obama 2', isFine: false}
                ]
            },
            {
                qID: 38,
                excerpt: 'How Much??? So...2+1',
                title: 'From Math',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                group: 3,
                answers: [
                    {opt: 'Clinton 2', isFine: false},
                    {opt: 'Bush 2', isFine: false},
                    {opt: '3', isFine: true},
                    {opt: 'Obama 2', isFine: false}
                ]
            },
            {
                qID: 39,
                excerpt: 'How Much??? So...2+2',
                title: 'From Math',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                group: 3,
                answers: [
                    {opt: 'Clinton 23', isFine: false},
                    {opt: 'Bush 23', isFine: false},
                    {opt: '4', isFine: true},
                    {opt: 'Obama 23', isFine: false}
                ]
            },
            {
                qID: 40,
                excerpt: 'Do you know me??? About light',
                title: 'Whats My Name?',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                group: 4,
                answers: [
                    {opt: 'Clinton 2', isFine: false},
                    {opt: 'Bush 2', isFine: false},
                    {opt: 'Thomas Edson', isFine: true},
                    {opt: 'Obama 2', isFine: false}
                ]
            },
            {
                qID: 41,
                excerpt: 'Do you know me??? Mohhamed',
                title: 'Whats My Name?',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                group: 4,
                answers: [
                    {opt: 'Clinton', isFine: false},
                    {opt: 'Bush', isFine: false},
                    {opt: 'Alli', isFine: true},
                    {opt: 'Obama', isFine: false}
                ]
            },
            {
                qID: 42,
                excerpt: 'Do you know me??? Jesus.',
                title: 'Whats My Name?',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                group: 4,
                answers: [
                    {opt: 'Clinton 2', isFine: false},
                    {opt: 'Bush 2', isFine: false},
                    {opt: 'Christ', isFine: true},
                    {opt: 'Obama 2', isFine: false}
                ]
            },
            {
                qID: 43,
                excerpt: 'Do you know me??? INdian',
                title: 'Whats My Name?',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                group: 4,
                answers: [
                    {opt: 'Clinton 23', isFine: false},
                    {opt: 'Bush 23', isFine: false},
                    {opt: 'Gandi', isFine: true},
                    {opt: 'Obama 23', isFine: false}
                ]
            },
            {
                qID: 44,
                excerpt: 'Do you know me??? So...2.',
                title: 'Whats My Name?',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                group: 4,
                answers: [
                    {opt: 'Clinton 2', isFine: false},
                    {opt: 'Bush 2', isFine: false},
                    {opt: 'Budda 2', isFine: true},
                    {opt: 'Obama 2', isFine: false}
                ]
            },
            {
                qID: 45,
                excerpt: 'Do you know me??? Namaste',
                title: 'Whats My Name?',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                group: 4,
                answers: [
                    {opt: 'Clinton 2', isFine: false},
                    {opt: 'Bush 2', isFine: false},
                    {opt: 'Budda 2', isFine: true},
                    {opt: 'Obama 2', isFine: false}
                ]
            },
            {
                qID: 46,
                excerpt: 'Hey joe Do you know me??? So...2.',
                title: 'Whats My Name?',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                group: 5,
                answers: [
                    {opt: 'Clinton 23', isFine: false},
                    {opt: 'Bush 23', isFine: false},
                    {opt: 'Hendrix 23', isFine: true},
                    {opt: 'Obama 23', isFine: false}
                ]
            },
            {
                qID: 47,
                excerpt: 'Riders on the Storm Do you know me??? So...2.',
                title: 'Whats My Name?',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                group: 5,
                answers: [
                    {opt: 'Clinton 2', isFine: false},
                    {opt: 'Bush 2', isFine: false},
                    {opt: 'Morrison', isFine: true},
                    {opt: 'Obama 2', isFine: false}
                ]
            },
            {
                qID: 48,
                excerpt: 'JANES....Do you know me??? So...2.48',
                title: 'Whats My Name? 48',
                img: 'http://www.datavizcatalogue.com/methods/images/top_images/area_graph.png',
                group: 5,
                answers: [
                    {opt: 'Clinton 2 48', isFine: false},
                    {opt: 'Bush 2 48', isFine: false},
                    {opt: 'joplin', isFine: true},
                    {opt: 'Obama 2 48', isFine: false}
                ]
            },
            {
                qID: 49,
                excerpt: 'Do you know me??? So...Sk8 Brazil.',
                title: 'Whats My Name?',
                img: null,
                group: 5,
                answers: [
                    {opt: 'Clinton 23', isFine: false},
                    {opt: 'Bush 23', isFine: false},
                    {opt: 'Bob Burnquist', isFine: true},
                    {opt: 'Obama 23', isFine: false}
                ]
            },
            {
                qID: 50,
                excerpt: 'Do you know me??? Iron Maiden',
                title: 'Whats My Name?',
                img: null,
                group: 5,
                answers: [
                    {opt: 'Clinton 2 50', isFine: false},
                    {opt: 'Bush 2 50', isFine: false},
                    {opt: 'Steve Harris', isFine: true},
                    {opt: 'Obama 2 50', isFine: false}
                ]
            },
        ]

